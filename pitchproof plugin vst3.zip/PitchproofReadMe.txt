Pitchproof Read Me

Greetings! Welcome to Pitchproof. It's an audio plug-in that shifts the pitch of the signal in a high-quality but old-school way. It's also a harmonizer so it can intelligently shift based on the note you play. And there's a guitar tuner. Slso midi to pitch routing.

Version: 1.1

Who made it?:
This plugin is from Aegean Music at http://aegeanmusic.com.
Noah Beamer is the project lead and holds the rights to Pitchproof etc.

Installation:
The only step to installation is placing pitchproof.dll (or the -x64 version) in your VST plugins folder and setting/refreshing the pug-in path in your audio application which may happen automatically.
Please see http://aegeanmusic.com/support-install although it shows the Amp Vision installation instructions it may still be helpful to get it installed.

Please Note:
This program took a lot of work and it would be appreciated if it was respected. It may not be hacked, distributed, uploaded by third parties, or abused in any way. If you are not sure if something is allowed please contact us.


Contact:
http://aegeanmusic.com/index.php?route=information/contact

or

aegeanmusic@gmail.com


License:
By using this program you are bound by the license agreement as described on our website:
http://aegeanmusic.com/software-policy

Credits / Thanks / Libraries used in the project:

Lib:DSPFilters
Website: github.com/vinniefalco/DSPFilters
License Link: http://www.opensource.org/licenses/mit-license.php

And VST, VSTGUI, etc.