﻿Balabolka, version 2.15.0.805
Copyright (c) 2006-2021 Ilya Morozov
All Rights Reserved

WWW: http://balabolka.site
E-mail: crossa@list.ru

许可证：免费软件
操作系统：Microsoft Windows XP/Vista/7/8/10
Microsoft Speech API：v4.0/5.0 及以上
Microsoft Speech Platform：v11.0



*** 便携版 ***

    便携式 Balabolka 不需要安装，可以从 USB 驱动器运行。 一台计算机必须至少安装一个语音。



*** 文本到语音引擎 ***

    Balabolka 使用文本转语音 (TTS) 引擎来读取文本文件。
    如果您安装了 TTS，您将在 Balabolka 的主窗口中看到可用语音列表。

    该程序支持 SAPI 4 和 SAPI 5 文本到语音引擎。
    SAPI 4 是一项较旧的技术，因此我建议使用 SAPI 5。

    如果您对一些更高质量的声音感兴趣，请参阅 Balabolka 的帮助文件。



*** Microsoft Speech Platform ***

    Microsoft Speech Platform 由运行时和运行时语言组成（用于语音识别和文本到语音的引擎）。
    语音识别和语音合成有单独的运行时语言。

    http://msdn.microsoft.com/en-us/library/hh361572.aspx

    使用以下步骤安装 Microsoft Speech Platform：

    1 从您的计算机上卸载任何先前版本的 Speech Platform Runtime。
    2 确定您使用的是 32 位还是 64 位操作系统。
    3 下载并安装与您的操作系统匹配的语音平台运行时。
    4 下载并安装用于语音平台的运行时语言。

    Balabolka 是 32 位应用程序。 您需要为 Microsoft Speech Platform 安装 32 位运行时包， 才能在 Balabolka 中使用它。



*** 捐赠 ***

    如果您想帮助 Balabolka，请购买我的软件 Cross+A：

    http://www.cross-plus-a.com

    只要人们为 Cross+A 付费，Balabolka 就会保持免费软件。

    谢谢你！

###