﻿Balabolka, verzió 2.15.0.805
Szerzői jog (c) 2006-2021 Ilya Morozov
Minden jog fenntartva

WWW: http://balabolka.site
E-mail: crossa@list.ru

Licenc: Freeware
Operációs rendszer: Microsoft Windows XP/Vista/7/8/10
Microsoft Speech API: v4.0/5.0 és újabb
Microsoft Speech Platform: v11.0



*** Hordozható verzió ***

    A hordozható Balabolka nem igényel telepítést és
    USB meghajtóról futtatható. A számítógépnek legalább egy előtelepített hanggal rendelkeznie kell.



*** Szövegfelolvasó modulok ***

    A Balabolka szövegfelolvasó (TTS) motort használ a szövegfájlok olvasásához.
    Ha van telepítve TTS, akkor látni fogja a rendelkezésre álló
    hangok listáját a Balabolka fő ablakában.

    A program támogatja a SAPI 4 és a SAPI 5 szövegfelolvasó modulokat.
    A SAPI 4 egy régebbi technológia, ezért javaslom a SAPI 5 használatát.

    Ha a jobb minőségű hangok érdeklik, tekintse meg a Balabolka súgóját.



*** Microsoft Speech Platform ***

    A Microsoft Speech Platform futtatókörnyezetből és futtatókörnyezet nyelvekből áll
    (a beszédfelismerés és a szövegfelolvasás motorjai). Külön futtatókörnyezet nyelvek
    vannak a beszédfelismeréshez és a beszédszintézishez.

    http://msdn.microsoft.com/en-us/library/hh361572.aspx

    Használja a következő lépéseket a Microsoft Speech Platform telepítéséhez:

    1 Távolítsa el a beszédplatform futtatókörnyezetének bármely korábbi verzióját a számítógépről.
    2 Határozza meg, hogy 32 bites vagy 64 bites operációs rendszert használ-e.
    3 Töltse le és telepítse az operációs rendszeréhez illeszkedő beszédplatform futtatókörnyezetét.
    4 Töltse le és telepítse a futtatókörnyezet nyelveket a beszédplatform használatához.

    A Balabolka 32 bites alkalmazás. Telepítenie kell a 32 bites futtatókörnyezet csomagot
    a Microsoft Speech Platformot, a Balabolkán belüli használathoz.



*** Adomány ***

    Ha segíteni szeretné a Balabolka fejlesztését, vásárolja meg a Cross+A szoftvert:

    http://www.cross-plus-a.com

    Mindaddig, amíg az emberek pénzt szánnak a Cross+A-ra, a Balabolka ingyenes marad.

    Köszönöm!  

###