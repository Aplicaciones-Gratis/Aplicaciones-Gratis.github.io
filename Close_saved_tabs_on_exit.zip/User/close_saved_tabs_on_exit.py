import sublime
import sublime_plugin
import os
import json

TABS_FILE = os.path.join(sublime.packages_path(), 'User', 'saved_tabs.json')

class Programcodigo(sublime_plugin.EventListener):

    def __init__(self):
        self.saved_tabs = self.load_saved_tabs()

    def on_init(self, views):
        for view in views:
            window = view.window()
            if window:
                self.close_only_saved_tabs(window)

        if window.active_view() and not window.active_view().is_dirty():
            self.saved_tabs.append(window.active_view().file_name())
            self.save_tabs_to_file(self.saved_tabs)

    def on_new(self, view):
        self.save_tabs(view)

    def on_load(self, view):
        self.save_tabs(view)

    def on_close(self, view):
        if view.file_name() in self.saved_tabs:
            self.saved_tabs.remove(view.file_name())
            sublime.set_timeout(lambda: self.save_tabs_to_file(self.saved_tabs), 100)

    def save_tabs(self, view):
        path = view.file_name()
        if path and path not in self.saved_tabs:
            self.saved_tabs.append(path)
            self.save_tabs_to_file(self.saved_tabs)

    def save_tabs_to_file(self, tabs):
        try:
            with open(TABS_FILE, 'w') as f:
                json.dump(tabs, f)
        except IOError as e:
            sublime.error_message(f"Error al guardar las pestañas: {e}")

    def close_only_saved_tabs(self, window):
        views = window.views()
        
        if window.active_view() and not window.active_view().is_dirty() and window.active_view().file_name() in self.saved_tabs:
            first_view = views[0] if views else None
            if first_view:
                window.focus_view(first_view)

        for v in views:
            filevname = v.file_name()
            if filevname in self.saved_tabs and not v.is_dirty():
                self.saved_tabs.remove(filevname)
                v.close()
            elif v.size() == 0:
                v.close()
        self.save_tabs_to_file(self.saved_tabs)

    def load_saved_tabs(self):
        try:
            if os.path.exists(TABS_FILE):
                with open(TABS_FILE, 'r') as f:
                    return json.load(f)
            return []
        except (IOError, json.JSONDecodeError) as e:
            sublime.error_message(f"Error al cargar las pestañas guardadas: {e}")
            return []